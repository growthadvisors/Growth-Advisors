﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GrowthAdvisors.Controllers
{
	public class OurServicesController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

		public ActionResult AdvisorySupportToExecutives()
		{
			return View();
		}

		public ActionResult StrategyAndBusinessPlanning()
		{
			return View();
		}

		public ActionResult Capital()
		{
			return View();
		}

		public ActionResult MAndA()
		{
			return View();
		}
				
		public ActionResult CeoCfoCooServices()
		{
			return View();
		}

		public ActionResult Negotiation()
		{
			return View();
		}

		public ActionResult Team()
		{
			return View();
		}

		public ActionResult LocationExpansion()
		{
			return View();
		}

		public ActionResult Processes()
		{
			return View();
		}

		public ActionResult MarketingAndAdvertising()
		{
			return View();
		}

		public ActionResult CustomerService()
		{
			return View();
		}

	}
}
